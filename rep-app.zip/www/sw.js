// كاش بسيط ليعمل التطبيق أوفلاين عند فتحه كموقع (PWA). داخل الـ APK لا حاجة له.
const V = 'rep-v1';
const FILES = ['./', 'index.html', 'style.css', 'js/app.js', 'js/core.js', 'js/db.js', 'js/util.js', 'js/sync.js'];
self.addEventListener('install', (e) => e.waitUntil(caches.open(V).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())));
self.addEventListener('activate', (e) => e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== V).map((x) => caches.delete(x)))).then(() => self.clients.claim())));
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(fetch(e.request).then((r) => { const c = r.clone(); caches.open(V).then((ch) => ch.put(e.request, c)); return r; }).catch(() => caches.match(e.request)));
});
